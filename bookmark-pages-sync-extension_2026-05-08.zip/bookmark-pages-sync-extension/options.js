const DEFAULTS = {
  githubBranch: "main",
  githubPath: "index.html",
  targetFolderNames: ["Public Bookmarks"],
  useDomainAllowlist: true,
  allowedDomains: [
    "qiita.com",
    "zenn.dev",
    "note.com",
    "medium.com",
    "dev.to",
    "arxiv.org",
    "paperswithcode.com",
    "developer.chrome.com",
    "docs.github.com",
    "stackoverflow.com",
    "stackexchange.com",
    "mozilla.org",
    "developer.mozilla.org"
  ],
  syncDelayMinutes: 1,
  pageTitle: "Public Bookmarks"
};

const elements = {
  githubOwner: document.getElementById("githubOwner"),
  githubRepo: document.getElementById("githubRepo"),
  githubBranch: document.getElementById("githubBranch"),
  githubPath: document.getElementById("githubPath"),
  githubToken: document.getElementById("githubToken"),
  targetFolderNames: document.getElementById("targetFolderNames"),
  useDomainAllowlist: document.getElementById("useDomainAllowlist"),
  allowedDomains: document.getElementById("allowedDomains"),
  pageTitle: document.getElementById("pageTitle"),
  syncDelayMinutes: document.getElementById("syncDelayMinutes"),
  status: document.getElementById("status"),
  save: document.getElementById("save"),
  syncNow: document.getElementById("syncNow"),
  clearToken: document.getElementById("clearToken"),
  loadDefaultDomains: document.getElementById("loadDefaultDomains")
};

init().catch(showError);

elements.save.addEventListener("click", () => saveSettings().catch(showError));
elements.syncNow.addEventListener("click", () => syncNow().catch(showError));
elements.clearToken.addEventListener("click", () => clearToken().catch(showError));
elements.loadDefaultDomains.addEventListener("click", () => {
  elements.allowedDomains.value = DEFAULTS.allowedDomains.join("\n");
});
elements.useDomainAllowlist.addEventListener("change", updateDomainAllowlistControls);

async function init() {
  const settings = await chrome.storage.local.get(Object.keys(DEFAULTS).concat([
    "githubOwner",
    "githubRepo",
    "githubToken",
    "lastSyncStatus"
  ]));

  elements.githubOwner.value = settings.githubOwner || "";
  elements.githubRepo.value = settings.githubRepo || "";
  elements.githubBranch.value = settings.githubBranch || DEFAULTS.githubBranch;
  elements.githubPath.value = !settings.githubPath || settings.githubPath === "index.md" ? DEFAULTS.githubPath : settings.githubPath;
  elements.githubToken.value = settings.githubToken || "";
  elements.targetFolderNames.value = toLines(settings.targetFolderNames || DEFAULTS.targetFolderNames);
  elements.useDomainAllowlist.checked = settings.useDomainAllowlist !== false;
  elements.allowedDomains.value = toLines(settings.allowedDomains || DEFAULTS.allowedDomains);
  updateDomainAllowlistControls();
  elements.pageTitle.value = settings.pageTitle || DEFAULTS.pageTitle;
  elements.syncDelayMinutes.value = settings.syncDelayMinutes || DEFAULTS.syncDelayMinutes;

  renderStatus(settings.lastSyncStatus || { state: "not-synced" });
}

async function saveSettings() {
  const settings = {
    githubOwner: elements.githubOwner.value.trim(),
    githubRepo: elements.githubRepo.value.trim(),
    githubBranch: elements.githubBranch.value.trim() || DEFAULTS.githubBranch,
    githubPath: elements.githubPath.value.trim() || DEFAULTS.githubPath,
    targetFolderNames: fromLines(elements.targetFolderNames.value),
    useDomainAllowlist: elements.useDomainAllowlist.checked,
    allowedDomains: normalizeDomains(fromLines(elements.allowedDomains.value)),
    pageTitle: elements.pageTitle.value.trim() || DEFAULTS.pageTitle,
    syncDelayMinutes: Math.max(1, Number(elements.syncDelayMinutes.value || DEFAULTS.syncDelayMinutes))
  };

  const token = elements.githubToken.value.trim();
  if (token) {
    settings.githubToken = token;
  }

  validateOptions(settings);
  await chrome.storage.local.set(settings);
  await renderCurrentStatus("saved");
}

async function syncNow() {
  await saveSettings();
  elements.status.textContent = "Syncing...";

  const response = await chrome.runtime.sendMessage({ type: "SYNC_NOW" });
  if (!response?.ok) {
    throw new Error(response?.error || "Sync failed");
  }

  await renderCurrentStatus("manual sync completed");
}

async function clearToken() {
  await chrome.storage.local.remove("githubToken");
  elements.githubToken.value = "";
  await renderCurrentStatus("token cleared");
}

function validateOptions(settings) {
  if (!settings.githubOwner) throw new Error("GitHub owner is required.");
  if (!settings.githubRepo) throw new Error("GitHub repo is required.");
  if (!/\.(html|md)$/i.test(settings.githubPath)) throw new Error("Output path should be index.html or a Markdown file path.");
  if (settings.targetFolderNames.length === 0) throw new Error("At least one target bookmark folder is required.");
  if (settings.useDomainAllowlist && settings.allowedDomains.length === 0) throw new Error("At least one allowed domain is required when allowlist filtering is enabled.");
}

function updateDomainAllowlistControls() {
  const enabled = elements.useDomainAllowlist.checked;
  elements.allowedDomains.disabled = !enabled;
  elements.loadDefaultDomains.disabled = !enabled;
}

async function renderCurrentStatus(localMessage) {
  const { lastSyncStatus } = await chrome.storage.local.get("lastSyncStatus");
  renderStatus({ localMessage, ...(lastSyncStatus || {}) });
}

function renderStatus(status) {
  elements.status.textContent = JSON.stringify(status, null, 2);
}

function showError(error) {
  elements.status.textContent = JSON.stringify({ state: "error", error: error.message }, null, 2);
}

function fromLines(text) {
  return [...new Set(
    String(text)
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)
  )];
}

function toLines(list) {
  return Array.isArray(list) ? list.join("\n") : "";
}

function normalizeDomains(domains) {
  return domains.map((domain) => domain.toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, ""));
}
