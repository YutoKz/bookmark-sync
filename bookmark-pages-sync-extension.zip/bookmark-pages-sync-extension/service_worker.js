const SYNC_ALARM_NAME = "debounced-bookmark-sync";
const DEFAULT_BRANCH = "main";
const DEFAULT_PATH = "index.md";
const DEFAULT_SYNC_DELAY_MINUTES = 1;

const DEFAULT_ALLOWED_DOMAINS = [
  "qiita.com",
  "zenn.dev",
  "note.com",
  "medium.com",
  "dev.to",
  "arxiv.org",
  "paperswithcode.com",
  "developer.chrome.com",
  "docs.github.com",
  "stackoverflow.com",
  "stackexchange.com",
  "mozilla.org",
  "developer.mozilla.org"
];

const SENSITIVE_QUERY_KEYS = new Set([
  "token",
  "access_token",
  "id_token",
  "refresh_token",
  "key",
  "api_key",
  "secret",
  "session",
  "auth",
  "authorization",
  "password",
  "pass",
  "code",
  "state",
  "jwt",
  "sig",
  "signature"
]);

const ALWAYS_BLOCKED_HOSTS = [
  "drive.google.com",
  "docs.google.com",
  "mail.google.com",
  "gmail.com",
  "notion.so",
  "slack.com"
];

chrome.runtime.onInstalled.addListener(async () => {
  await ensureDefaultSettings();
  await syncBookmarksToGitHub("installed");
});

chrome.runtime.onStartup.addListener(async () => {
  await syncBookmarksToGitHub("startup");
});

chrome.bookmarks.onCreated.addListener(scheduleDebouncedSync);
chrome.bookmarks.onChanged.addListener(scheduleDebouncedSync);
chrome.bookmarks.onRemoved.addListener(scheduleDebouncedSync);
chrome.bookmarks.onMoved.addListener(scheduleDebouncedSync);
chrome.bookmarks.onChildrenReordered.addListener(scheduleDebouncedSync);
chrome.bookmarks.onImportEnded.addListener(scheduleDebouncedSync);

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === SYNC_ALARM_NAME) {
    await syncBookmarksToGitHub("debounced-change");
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "SYNC_NOW") {
    syncBookmarksToGitHub("manual")
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_DEFAULT_ALLOWED_DOMAINS") {
    sendResponse({ ok: true, domains: DEFAULT_ALLOWED_DOMAINS });
    return false;
  }

  return false;
});

async function ensureDefaultSettings() {
  const current = await chrome.storage.local.get([
    "githubBranch",
    "githubPath",
    "targetFolderNames",
    "allowedDomains",
    "syncDelayMinutes"
  ]);

  const defaults = {};

  if (!current.githubBranch) defaults.githubBranch = DEFAULT_BRANCH;
  if (!current.githubPath) defaults.githubPath = DEFAULT_PATH;
  if (!Array.isArray(current.targetFolderNames)) defaults.targetFolderNames = ["Public Bookmarks"];
  if (!Array.isArray(current.allowedDomains)) defaults.allowedDomains = DEFAULT_ALLOWED_DOMAINS;
  if (!Number.isFinite(current.syncDelayMinutes)) defaults.syncDelayMinutes = DEFAULT_SYNC_DELAY_MINUTES;

  if (Object.keys(defaults).length > 0) {
    await chrome.storage.local.set(defaults);
  }
}

async function scheduleDebouncedSync() {
  const { syncDelayMinutes } = await chrome.storage.local.get("syncDelayMinutes");
  const delayInMinutes = normalizePositiveNumber(syncDelayMinutes, DEFAULT_SYNC_DELAY_MINUTES);

  await chrome.alarms.clear(SYNC_ALARM_NAME);
  await chrome.alarms.create(SYNC_ALARM_NAME, { delayInMinutes });
  await writeStatus({ state: "scheduled", reason: "bookmark-change", scheduledDelayMinutes: delayInMinutes });
}

async function syncBookmarksToGitHub(reason) {
  try {
    await writeStatus({ state: "running", reason });

    const settings = await loadSettings();
    validateSettings(settings);

    const allFolders = await findTargetBookmarkFolders(settings.targetFolderNames);
    const markdown = buildMarkdownPage({
      folders: allFolders,
      allowedDomains: settings.allowedDomains,
      pageTitle: settings.pageTitle || "Public Bookmarks"
    });

    const result = await putGitHubFile({
      owner: settings.githubOwner,
      repo: settings.githubRepo,
      branch: settings.githubBranch || DEFAULT_BRANCH,
      path: settings.githubPath || DEFAULT_PATH,
      token: settings.githubToken,
      content: markdown,
      message: `Update public bookmarks (${reason})`
    });

    const summary = summarizeMarkdown(markdown);
    await writeStatus({
      state: "success",
      reason,
      githubPath: settings.githubPath || DEFAULT_PATH,
      commitSha: result?.commit?.sha || null,
      htmlUrl: result?.content?.html_url || null,
      ...summary
    });

    return { ...summary, commitSha: result?.commit?.sha || null };
  } catch (error) {
    await writeStatus({ state: "error", reason, error: error.message });
    throw error;
  }
}

async function loadSettings() {
  await ensureDefaultSettings();
  return await chrome.storage.local.get([
    "githubOwner",
    "githubRepo",
    "githubBranch",
    "githubPath",
    "githubToken",
    "targetFolderNames",
    "allowedDomains",
    "syncDelayMinutes",
    "pageTitle"
  ]);
}

function validateSettings(settings) {
  const required = ["githubOwner", "githubRepo", "githubToken"];
  for (const key of required) {
    if (!settings[key] || typeof settings[key] !== "string") {
      throw new Error(`Missing setting: ${key}`);
    }
  }

  if (!Array.isArray(settings.targetFolderNames) || settings.targetFolderNames.length === 0) {
    throw new Error("At least one target bookmark folder is required.");
  }

  if (!Array.isArray(settings.allowedDomains) || settings.allowedDomains.length === 0) {
    throw new Error("At least one allowed domain is required.");
  }
}

async function findTargetBookmarkFolders(targetFolderNames) {
  const tree = await chrome.bookmarks.getTree();
  const names = normalizeStringList(targetFolderNames);
  const byName = new Map(names.map((name) => [name, []]));

  function walk(nodes, pathParts = []) {
    for (const node of nodes) {
      const title = node.title || "";
      const currentPath = title ? [...pathParts, title] : pathParts;

      if (!node.url && byName.has(title)) {
        byName.get(title).push({ node, path: currentPath.join(" / ") });
      }

      if (node.children) {
        walk(node.children, currentPath);
      }
    }
  }

  walk(tree);

  const folders = [];
  const missing = [];
  const duplicateErrors = [];

  for (const name of names) {
    const matches = byName.get(name) || [];
    if (matches.length === 0) {
      missing.push(name);
    } else if (matches.length > 1) {
      duplicateErrors.push(`${name}: ${matches.map((m) => m.path).join(" | ")}`);
    } else {
      folders.push({ name, path: matches[0].path, node: matches[0].node });
    }
  }

  if (missing.length > 0) {
    throw new Error(`Target bookmark folder not found: ${missing.join(", ")}`);
  }

  if (duplicateErrors.length > 0) {
    throw new Error(`Duplicate target bookmark folder names found. Rename folders to make them unique. ${duplicateErrors.join("; ")}`);
  }

  return folders;
}

function buildMarkdownPage({ folders, allowedDomains, pageTitle }) {
  const stats = { included: 0, excluded: 0 };
  const normalizedDomains = normalizeDomains(allowedDomains);
  const now = new Date();

  const lines = [
    "---",
    `title: ${escapeYamlString(pageTitle)}`,
    "---",
    "",
    `# ${escapeMarkdown(pageTitle)}`,
    "",
    `Last synced: ${formatDateTime(now)}`,
    "",
    "> This page is automatically generated from selected Chrome bookmark folders. Only whitelisted public HTTPS domains are included.",
    ""
  ];

  for (const folder of folders) {
    lines.push(`## ${escapeMarkdown(folder.name)}`);
    lines.push("");
    appendFolderChildren(folder.node.children || [], lines, 3, normalizedDomains, stats);
    lines.push("");
  }

  lines.push("---");
  lines.push("");
  lines.push("## Sync summary");
  lines.push("");
  lines.push(`- Included bookmarks: ${stats.included}`);
  lines.push(`- Excluded bookmarks: ${stats.excluded}`);
  lines.push(`- Target folders: ${folders.map((folder) => `\`${escapeInlineCode(folder.name)}\``).join(", ")}`);
  lines.push(`- Allowed domains: ${normalizedDomains.map((domain) => `\`${escapeInlineCode(domain)}\``).join(", ")}`);
  lines.push("");

  return lines.join("\n");
}

function appendFolderChildren(nodes, lines, headingLevel, allowedDomains, stats) {
  for (const node of nodes) {
    if (node.url) {
      const check = classifyBookmarkUrl(node.url, allowedDomains);
      if (check.allowed) {
        const title = escapeMarkdown(node.title || node.url);
        const safeUrl = sanitizeUrlForMarkdown(node.url);
        lines.push(`- [${title}](${safeUrl})`);
        stats.included += 1;
      } else {
        stats.excluded += 1;
      }
      continue;
    }

    const hasAllowedDescendant = containsAllowedBookmark(node, allowedDomains);
    if (!hasAllowedDescendant) {
      continue;
    }

    lines.push("");
    lines.push(`${"#".repeat(Math.min(headingLevel, 6))} ${escapeMarkdown(node.title || "Untitled")}`);
    lines.push("");
    appendFolderChildren(node.children || [], lines, headingLevel + 1, allowedDomains, stats);
  }
}

function containsAllowedBookmark(node, allowedDomains) {
  if (!node.children) return false;
  for (const child of node.children) {
    if (child.url && classifyBookmarkUrl(child.url, allowedDomains).allowed) {
      return true;
    }
    if (!child.url && containsAllowedBookmark(child, allowedDomains)) {
      return true;
    }
  }
  return false;
}

function classifyBookmarkUrl(rawUrl, allowedDomains) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    return { allowed: false, reason: "invalid-url" };
  }

  if (url.protocol !== "https:") {
    return { allowed: false, reason: "non-https" };
  }

  const hostname = url.hostname.toLowerCase();

  if (
    hostname === "localhost" ||
    hostname === "127.0.0.1" ||
    hostname.endsWith(".local") ||
    hostname.endsWith(".localhost")
  ) {
    return { allowed: false, reason: "local-host" };
  }

  if (ALWAYS_BLOCKED_HOSTS.some((blocked) => hostname === blocked || hostname.endsWith(`.${blocked}`))) {
    return { allowed: false, reason: "always-blocked-host" };
  }

  for (const key of url.searchParams.keys()) {
    if (SENSITIVE_QUERY_KEYS.has(key.toLowerCase())) {
      return { allowed: false, reason: "sensitive-query" };
    }
  }

  const domainAllowed = allowedDomains.some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
  if (!domainAllowed) {
    return { allowed: false, reason: "domain-not-allowed" };
  }

  return { allowed: true, reason: "allowed" };
}

async function putGitHubFile({ owner, repo, branch, path, token, content, message }) {
  const getUrl = new URL(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${encodePath(path)}`);
  getUrl.searchParams.set("ref", branch);

  let sha;
  const getRes = await fetch(getUrl.toString(), {
    headers: githubHeaders(token)
  });

  if (getRes.ok) {
    const current = await getRes.json();
    sha = current.sha;
  } else if (getRes.status !== 404) {
    const text = await getRes.text();
    throw new Error(`Failed to fetch current GitHub file: ${getRes.status} ${text}`);
  }

  const putUrl = `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${encodePath(path)}`;
  const putRes = await fetch(putUrl, {
    method: "PUT",
    headers: {
      ...githubHeaders(token),
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      message,
      content: base64EncodeUtf8(content),
      branch,
      ...(sha ? { sha } : {})
    })
  });

  if (!putRes.ok) {
    const text = await putRes.text();
    throw new Error(`GitHub update failed: ${putRes.status} ${text}`);
  }

  return await putRes.json();
}

function githubHeaders(token) {
  return {
    "Authorization": `Bearer ${token}`,
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28"
  };
}

function encodePath(path) {
  return String(path)
    .split("/")
    .map((part) => encodeURIComponent(part))
    .join("/");
}

function base64EncodeUtf8(text) {
  const bytes = new TextEncoder().encode(text);
  let binary = "";
  const chunkSize = 0x8000;

  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }

  return btoa(binary);
}

async function writeStatus(status) {
  await chrome.storage.local.set({
    lastSyncStatus: {
      ...status,
      updatedAt: new Date().toISOString()
    }
  });
}

function summarizeMarkdown(markdown) {
  const includedMatch = markdown.match(/- Included bookmarks: (\d+)/);
  const excludedMatch = markdown.match(/- Excluded bookmarks: (\d+)/);
  return {
    included: includedMatch ? Number(includedMatch[1]) : 0,
    excluded: excludedMatch ? Number(excludedMatch[1]) : 0
  };
}

function normalizeStringList(value) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.map((item) => String(item).trim()).filter(Boolean))];
}

function normalizeDomains(value) {
  return normalizeStringList(value).map((domain) => domain.toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, ""));
}

function normalizePositiveNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

function sanitizeUrlForMarkdown(rawUrl) {
  return String(rawUrl).replace(/\)/g, "%29").replace(/\(/g, "%28");
}

function escapeMarkdown(text) {
  return String(text)
    .replace(/\\/g, "\\\\")
    .replace(/\[/g, "\\[")
    .replace(/\]/g, "\\]")
    .replace(/\n/g, " ");
}

function escapeInlineCode(text) {
  return String(text).replace(/`/g, "\\`");
}

function escapeYamlString(text) {
  return JSON.stringify(String(text));
}

function formatDateTime(date) {
  return date.toLocaleString("ja-JP", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  }) + " JST";
}
