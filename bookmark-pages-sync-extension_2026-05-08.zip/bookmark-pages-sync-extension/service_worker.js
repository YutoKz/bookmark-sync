const SYNC_ALARM_NAME = "debounced-bookmark-sync";
const DEFAULT_BRANCH = "main";
const DEFAULT_PATH = "index.html";
const DEFAULT_SYNC_DELAY_MINUTES = 1;

const DEFAULT_ALLOWED_DOMAINS = [
  "qiita.com",
  "zenn.dev",
  "note.com",
  "medium.com",
  "dev.to",
  "arxiv.org",
  "paperswithcode.com",
  "developer.chrome.com",
  "docs.github.com",
  "stackoverflow.com",
  "stackexchange.com",
  "mozilla.org",
  "developer.mozilla.org"
];

const SENSITIVE_QUERY_KEYS = new Set([
  "token",
  "access_token",
  "id_token",
  "refresh_token",
  "key",
  "api_key",
  "secret",
  "session",
  "auth",
  "authorization",
  "password",
  "pass",
  "code",
  "state",
  "jwt",
  "sig",
  "signature"
]);

const ALWAYS_BLOCKED_HOSTS = [
  "drive.google.com",
  "docs.google.com",
  "mail.google.com",
  "gmail.com",
  "notion.so",
  "slack.com"
];

chrome.runtime.onInstalled.addListener(async () => {
  await ensureDefaultSettings();
  await syncBookmarksToGitHub("installed");
});

chrome.runtime.onStartup.addListener(async () => {
  await syncBookmarksToGitHub("startup");
});

chrome.bookmarks.onCreated.addListener(scheduleDebouncedSync);
chrome.bookmarks.onChanged.addListener(scheduleDebouncedSync);
chrome.bookmarks.onRemoved.addListener(scheduleDebouncedSync);
chrome.bookmarks.onMoved.addListener(scheduleDebouncedSync);
chrome.bookmarks.onChildrenReordered.addListener(scheduleDebouncedSync);
chrome.bookmarks.onImportEnded.addListener(scheduleDebouncedSync);

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === SYNC_ALARM_NAME) {
    await syncBookmarksToGitHub("debounced-change");
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "SYNC_NOW") {
    syncBookmarksToGitHub("manual")
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_DEFAULT_ALLOWED_DOMAINS") {
    sendResponse({ ok: true, domains: DEFAULT_ALLOWED_DOMAINS });
    return false;
  }

  return false;
});

async function ensureDefaultSettings() {
  const current = await chrome.storage.local.get([
    "githubBranch",
    "githubPath",
    "targetFolderNames",
    "allowedDomains",
    "useDomainAllowlist",
    "syncDelayMinutes"
  ]);

  const defaults = {};

  if (!current.githubBranch) defaults.githubBranch = DEFAULT_BRANCH;
  if (!current.githubPath || current.githubPath === "index.md") defaults.githubPath = DEFAULT_PATH;
  if (!Array.isArray(current.targetFolderNames)) defaults.targetFolderNames = ["Public Bookmarks"];
  if (!Array.isArray(current.allowedDomains)) defaults.allowedDomains = DEFAULT_ALLOWED_DOMAINS;
  if (typeof current.useDomainAllowlist !== "boolean") defaults.useDomainAllowlist = true;
  if (!Number.isFinite(current.syncDelayMinutes)) defaults.syncDelayMinutes = DEFAULT_SYNC_DELAY_MINUTES;

  if (Object.keys(defaults).length > 0) {
    await chrome.storage.local.set(defaults);
  }
}

async function scheduleDebouncedSync() {
  const { syncDelayMinutes } = await chrome.storage.local.get("syncDelayMinutes");
  const delayInMinutes = normalizePositiveNumber(syncDelayMinutes, DEFAULT_SYNC_DELAY_MINUTES);

  await chrome.alarms.clear(SYNC_ALARM_NAME);
  await chrome.alarms.create(SYNC_ALARM_NAME, { delayInMinutes });
  await writeStatus({ state: "scheduled", reason: "bookmark-change", scheduledDelayMinutes: delayInMinutes });
}

async function syncBookmarksToGitHub(reason) {
  try {
    await writeStatus({ state: "running", reason });

    const settings = await loadSettings();
    validateSettings(settings);

    const allFolders = await findTargetBookmarkFolders(settings.targetFolderNames);
    const page = buildHtmlPage({
      folders: allFolders,
      allowedDomains: settings.allowedDomains,
      useDomainAllowlist: settings.useDomainAllowlist !== false,
      pageTitle: settings.pageTitle || "Public Bookmarks"
    });

    const result = await putGitHubFile({
      owner: settings.githubOwner,
      repo: settings.githubRepo,
      branch: settings.githubBranch || DEFAULT_BRANCH,
      path: settings.githubPath || DEFAULT_PATH,
      token: settings.githubToken,
      content: page,
      message: `Update public bookmarks (${reason})`
    });

    const summary = summarizePublishedPage(page);
    await writeStatus({
      state: "success",
      reason,
      githubPath: settings.githubPath || DEFAULT_PATH,
      commitSha: result?.commit?.sha || null,
      htmlUrl: result?.content?.html_url || null,
      ...summary
    });

    return { ...summary, commitSha: result?.commit?.sha || null };
  } catch (error) {
    await writeStatus({ state: "error", reason, error: error.message });
    throw error;
  }
}

async function loadSettings() {
  await ensureDefaultSettings();
  return await chrome.storage.local.get([
    "githubOwner",
    "githubRepo",
    "githubBranch",
    "githubPath",
    "githubToken",
    "targetFolderNames",
    "allowedDomains",
    "useDomainAllowlist",
    "syncDelayMinutes",
    "pageTitle"
  ]);
}

function validateSettings(settings) {
  const required = ["githubOwner", "githubRepo", "githubToken"];
  for (const key of required) {
    if (!settings[key] || typeof settings[key] !== "string") {
      throw new Error(`Missing setting: ${key}`);
    }
  }

  if (!Array.isArray(settings.targetFolderNames) || settings.targetFolderNames.length === 0) {
    throw new Error("At least one target bookmark folder is required.");
  }

  if (settings.useDomainAllowlist !== false && (!Array.isArray(settings.allowedDomains) || settings.allowedDomains.length === 0)) {
    throw new Error("At least one allowed domain is required when domain allowlist filtering is enabled.");
  }
}

async function findTargetBookmarkFolders(targetFolderNames) {
  const tree = await chrome.bookmarks.getTree();
  const targets = normalizeBookmarkFolderTargets(targetFolderNames);
  const allFolders = [];

  function walk(nodes, pathParts = []) {
    for (const node of nodes) {
      const title = node.title || "";
      const currentPath = title ? [...pathParts, title] : pathParts;

      if (!node.url && title) {
        allFolders.push({ node, title, pathParts: currentPath, path: currentPath.join(" / ") });
      }

      if (node.children) {
        walk(node.children, currentPath);
      }
    }
  }

  walk(tree);

  const folders = [];
  const missing = [];
  const duplicateErrors = [];

  for (const target of targets) {
    const matches = allFolders.filter((folder) => matchesBookmarkFolderTarget(folder, target));
    if (matches.length === 0) {
      missing.push(target.raw);
    } else if (matches.length > 1) {
      duplicateErrors.push(`${target.raw}: ${matches.map((m) => m.path).join(" | ")}`);
    } else {
      folders.push({
        name: target.parts.length > 1 ? target.parts.join(" / ") : matches[0].title,
        path: matches[0].path,
        node: matches[0].node
      });
    }
  }

  if (missing.length > 0) {
    throw new Error(`Target bookmark folder not found: ${missing.join(", ")}`);
  }

  if (duplicateErrors.length > 0) {
    throw new Error(`Duplicate target bookmark folders found. Use nested paths to make them unique. ${duplicateErrors.join("; ")}`);
  }

  return folders;
}

function normalizeBookmarkFolderTargets(value) {
  return normalizeStringList(value).map((raw) => ({
    raw,
    parts: splitBookmarkFolderPath(raw)
  }));
}

function splitBookmarkFolderPath(value) {
  return String(value)
    .split("/")
    .map((part) => part.trim())
    .filter(Boolean);
}

function matchesBookmarkFolderTarget(folder, target) {
  if (folder.title === target.raw) {
    return true;
  }

  if (target.parts.length === 1) {
    return folder.title === target.parts[0];
  }

  return pathEndsWith(folder.pathParts, target.parts);
}

function pathEndsWith(pathParts, targetParts) {
  if (targetParts.length > pathParts.length) return false;
  const offset = pathParts.length - targetParts.length;

  return targetParts.every((part, index) => pathParts[offset + index] === part);
}

function buildHtmlPage({ folders, allowedDomains, useDomainAllowlist = true, pageTitle }) {
  const stats = { included: 0, excluded: 0 };
  const normalizedDomains = normalizeDomains(allowedDomains);
  const filterOptions = { allowedDomains: normalizedDomains, useDomainAllowlist };
  const now = new Date();
  const folderSections = folders.map((folder) => renderFolderSection(folder, filterOptions, stats)).join("\n");

  return `<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(pageTitle)}</title>
  <style>
    :root {
      color-scheme: light;
      --bg: #f7f5f0;
      --panel: #ffffff;
      --text: #202124;
      --muted: #6b6257;
      --line: #ded7cc;
      --accent: #176f8f;
      --accent-strong: #0f536f;
      --folder: #7a4f13;
      --shadow: 0 18px 60px rgba(43, 35, 22, 0.10);
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      min-height: 100vh;
      color: var(--text);
      background:
        radial-gradient(circle at top left, rgba(99, 102, 241, 0.18), transparent 35%),
        radial-gradient(circle at bottom right, rgba(6, 182, 212, 0.16), transparent 35%),
        linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
      font: 16px/1.65 system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }

    a { color: var(--accent-strong); text-decoration-thickness: 0.08em; text-underline-offset: 0.18em; }
    a:hover { color: var(--accent); }

    .page {
      width: min(1120px, calc(100% - 32px));
      margin: 0 auto;
      padding: 48px 0 56px;
    }

    .hero {
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 24px;
      align-items: end;
      padding: 32px 0 28px;
      border-bottom: 1px solid var(--line);
    }

    h1 {
      margin: 0;
      font-size: clamp(2rem, 4vw, 4.2rem);
      line-height: 1.02;
      letter-spacing: 0;
    }

    .subtitle {
      max-width: 720px;
      margin: 16px 0 0;
      color: var(--muted);
      font-size: 1rem;
    }

    .sync-meta {
      display: grid;
      gap: 6px;
      min-width: 220px;
      padding: 14px 16px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: rgba(255, 255, 255, 0.72);
    }

    .sync-meta span { color: var(--muted); font-size: 0.82rem; }
    .sync-meta strong { font-size: 0.95rem; }

    .folders {
      display: grid;
      gap: 24px;
      margin-top: 28px;
    }

    .folder-section {
      padding: 24px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: rgba(255, 255, 255, 0.86);
      box-shadow: var(--shadow);
    }

    .folder-heading {
      display: flex;
      flex-wrap: wrap;
      gap: 10px 14px;
      align-items: baseline;
      margin-bottom: 12px;
    }

    h2 {
      margin: 0;
      font-size: 1.35rem;
      line-height: 1.25;
      letter-spacing: 0;
    }

    .path {
      color: var(--muted);
      font-size: 0.86rem;
    }

    .bookmark-tree,
    .bookmark-tree ol {
      list-style: none;
      margin: 0;
      padding-left: 0;
    }

    .bookmark-tree ol {
      margin-top: 8px;
      padding-left: 22px;
      border-left: 1px solid var(--line);
    }

    .bookmark-tree li { margin: 8px 0; }

    .folder-label {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: var(--folder);
      font-weight: 700;
    }

    .folder-label::before {
      content: "";
      width: 0.85em;
      height: 0.62em;
      border-radius: 2px;
      background: linear-gradient(180deg, #d99d36, #a56d1b);
      box-shadow: inset 0 2px 0 rgba(255, 255, 255, 0.32);
    }

    .bookmark-link {
      display: inline-flex;
      flex-wrap: wrap;
      gap: 6px 9px;
      align-items: baseline;
      max-width: 100%;
      padding: 4px 0;
    }

    .domain {
      color: var(--muted);
      font-size: 0.82rem;
    }

    .embed-card {
      overflow: hidden;
      margin: 12px 0 16px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--panel);
    }

    .embed-header {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      gap: 8px 14px;
      padding: 12px 14px;
      border-bottom: 1px solid var(--line);
      background: #fbfaf7;
    }

    .embed-frame {
      display: block;
      width: 100%;
      height: min(72vh, 720px);
      min-height: 420px;
      border: 0;
      background: #f1f3f4;
    }

    .summary {
      margin-top: 28px;
      padding-top: 18px;
      border-top: 1px solid var(--line);
      color: var(--muted);
      font-size: 0.92rem;
    }

    .summary ul {
      display: flex;
      flex-wrap: wrap;
      gap: 8px 18px;
      margin: 8px 0 0;
      padding: 0;
      list-style: none;
    }

    @media (max-width: 760px) {
      .page { width: min(100% - 24px, 1120px); padding-top: 28px; }
      .hero { grid-template-columns: 1fr; align-items: start; }
      .folder-section { padding: 18px; }
      .embed-frame { min-height: 320px; height: 62vh; }
    }
  </style>
</head>
<body>
  <main class="page">
    <header class="hero">
      <div>
        <h1>${escapeHtml(pageTitle)}</h1>
        <p class="subtitle">Selected public bookmarks, organized from Chrome folders and filtered before publishing.</p>
      </div>
      <div class="sync-meta" aria-label="Sync information">
        <span>Last synced</span>
        <strong>${escapeHtml(formatDateTime(now))}</strong>
      </div>
    </header>

    <div class="folders">
${folderSections}
    </div>

    <footer class="summary">
      <strong>Sync summary</strong>
      <ul>
        <li>Included bookmarks: ${stats.included}</li>
        <li>Excluded bookmarks: ${stats.excluded}</li>
        <li>Target folders: ${folders.map((folder) => escapeHtml(folder.name)).join(", ")}</li>
        <li>Domain filter: ${useDomainAllowlist ? "Allowlist" : "Any safe HTTPS domain"}</li>
      </ul>
    </footer>
  </main>
</body>
</html>`;
}

function renderFolderSection(folder, filterOptions, stats) {
  const items = renderBookmarkNodes(folder.node.children || [], filterOptions, stats).join("\n");
  const body = items ? `<ol class="bookmark-tree">\n${items}\n      </ol>` : `<p class="empty">No publishable bookmarks in this folder.</p>`;

  return `      <section class="folder-section">
        <div class="folder-heading">
          <h2>${escapeHtml(folder.name)}</h2>
          <span class="path">${escapeHtml(folder.path)}</span>
        </div>
        ${body}
      </section>`;
}

function renderBookmarkNodes(nodes, filterOptions, stats) {
  const items = [];

  for (const node of nodes) {
    if (node.url) {
      const check = classifyBookmarkUrl(node.url, filterOptions.allowedDomains, filterOptions.useDomainAllowlist);
      if (check.allowed) {
        items.push(renderBookmarkItem(node));
        stats.included += 1;
      } else {
        stats.excluded += 1;
      }
      continue;
    }

    if (!containsAllowedBookmark(node, filterOptions)) {
      continue;
    }

    const children = renderBookmarkNodes(node.children || [], filterOptions, stats).join("\n");
    items.push(`          <li class="folder-item">
            <span class="folder-label">${escapeHtml(node.title || "Untitled")}</span>
            <ol>
${children}
            </ol>
          </li>`);
  }

  return items;
}

function renderBookmarkItem(node) {
  const presentation = getBookmarkPresentation(node);

  if (presentation.embedUrl) {
    return `          <li class="bookmark-item embed-item">
            <article class="embed-card">
              <div class="embed-header">
                <a href="${presentation.url}" target="_blank" rel="noopener noreferrer">${presentation.title}</a>
                <span class="domain">${presentation.domain}</span>
              </div>
              <iframe class="embed-frame" src="${presentation.embedUrl}" loading="lazy" allow="autoplay"></iframe>
            </article>
          </li>`;
  }

  return `          <li class="bookmark-item">
            <span class="bookmark-link"><a href="${presentation.url}" target="_blank" rel="noopener noreferrer">${presentation.title}</a><span class="domain">${presentation.domain}</span></span>
          </li>`;
}

function getBookmarkPresentation(node) {
  const rawUrl = String(node.url || "");
  return {
    title: escapeHtml(node.title || rawUrl),
    url: escapeHtml(rawUrl),
    domain: escapeHtml(getDomainLabel(rawUrl)),
    embedUrl: escapeHtml(getGoogleDrivePreviewUrl(rawUrl) || "")
  };
}

function getGoogleDrivePreviewUrl(rawUrl) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    return null;
  }

  const hostname = url.hostname.toLowerCase();
  if (hostname !== "drive.google.com") {
    return null;
  }

  const fileMatch = url.pathname.match(/\/file\/d\/([^/]+)/);
  const id = fileMatch?.[1] || url.searchParams.get("id");
  if (!id || !/^[a-zA-Z0-9_-]+$/.test(id)) {
    return null;
  }

  return `https://drive.google.com/file/d/${encodeURIComponent(id)}/preview`;
}

function getDomainLabel(rawUrl) {
  try {
    return new URL(rawUrl).hostname.replace(/^www\./, "");
  } catch {
    return "link";
  }
}

function containsAllowedBookmark(node, filterOptions) {
  if (!node.children) return false;
  for (const child of node.children) {
    if (child.url && classifyBookmarkUrl(child.url, filterOptions.allowedDomains, filterOptions.useDomainAllowlist).allowed) {
      return true;
    }
    if (!child.url && containsAllowedBookmark(child, filterOptions)) {
      return true;
    }
  }
  return false;
}
function classifyBookmarkUrl(rawUrl, allowedDomains, useDomainAllowlist = true) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    return { allowed: false, reason: "invalid-url" };
  }

  if (url.protocol !== "https:") {
    return { allowed: false, reason: "non-https" };
  }

  const hostname = url.hostname.toLowerCase();

  if (
    hostname === "localhost" ||
    hostname === "127.0.0.1" ||
    hostname.endsWith(".local") ||
    hostname.endsWith(".localhost")
  ) {
    return { allowed: false, reason: "local-host" };
  }

  for (const key of url.searchParams.keys()) {
    if (SENSITIVE_QUERY_KEYS.has(key.toLowerCase())) {
      return { allowed: false, reason: "sensitive-query" };
    }
  }

  if (hostname === "drive.google.com" && getGoogleDrivePreviewUrl(rawUrl)) {
    return { allowed: true, reason: "google-drive-preview" };
  }

  if (ALWAYS_BLOCKED_HOSTS.some((blocked) => hostname === blocked || hostname.endsWith(`.${blocked}`))) {
    return { allowed: false, reason: "always-blocked-host" };
  }

  if (!useDomainAllowlist) {
    return { allowed: true, reason: "allowed-any-domain" };
  }

  const domainAllowed = allowedDomains.some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
  if (!domainAllowed) {
    return { allowed: false, reason: "domain-not-allowed" };
  }

  return { allowed: true, reason: "allowed" };
}

async function putGitHubFile({ owner, repo, branch, path, token, content, message }) {
  const getUrl = new URL(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${encodePath(path)}`);
  getUrl.searchParams.set("ref", branch);

  let sha;
  const getRes = await fetch(getUrl.toString(), {
    headers: githubHeaders(token)
  });

  if (getRes.ok) {
    const current = await getRes.json();
    sha = current.sha;
  } else if (getRes.status !== 404) {
    const text = await getRes.text();
    throw new Error(`Failed to fetch current GitHub file: ${getRes.status} ${text}`);
  }

  const putUrl = `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${encodePath(path)}`;
  const putRes = await fetch(putUrl, {
    method: "PUT",
    headers: {
      ...githubHeaders(token),
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      message,
      content: base64EncodeUtf8(content),
      branch,
      ...(sha ? { sha } : {})
    })
  });

  if (!putRes.ok) {
    const text = await putRes.text();
    throw new Error(`GitHub update failed: ${putRes.status} ${text}`);
  }

  return await putRes.json();
}

function githubHeaders(token) {
  return {
    "Authorization": `Bearer ${token}`,
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28"
  };
}

function encodePath(path) {
  return String(path)
    .split("/")
    .map((part) => encodeURIComponent(part))
    .join("/");
}

function base64EncodeUtf8(text) {
  const bytes = new TextEncoder().encode(text);
  let binary = "";
  const chunkSize = 0x8000;

  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }

  return btoa(binary);
}

async function writeStatus(status) {
  await chrome.storage.local.set({
    lastSyncStatus: {
      ...status,
      updatedAt: new Date().toISOString()
    }
  });
}

function summarizePublishedPage(page) {
  const includedMatch = page.match(/Included bookmarks: (\d+)/);
  const excludedMatch = page.match(/Excluded bookmarks: (\d+)/);
  return {
    included: includedMatch ? Number(includedMatch[1]) : 0,
    excluded: excludedMatch ? Number(excludedMatch[1]) : 0
  };
}

function normalizeStringList(value) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.map((item) => String(item).trim()).filter(Boolean))];
}

function normalizeDomains(value) {
  return normalizeStringList(value).map((domain) => domain.toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, ""));
}

function normalizePositiveNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

function sanitizeUrlForMarkdown(rawUrl) {
  return String(rawUrl).replace(/\)/g, "%29").replace(/\(/g, "%28");
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeMarkdown(text) {
  return String(text)
    .replace(/\\/g, "\\\\")
    .replace(/\[/g, "\\[")
    .replace(/\]/g, "\\]")
    .replace(/\n/g, " ");
}

function escapeInlineCode(text) {
  return String(text).replace(/`/g, "\\`");
}

function escapeYamlString(text) {
  return JSON.stringify(String(text));
}

function formatDateTime(date) {
  return date.toLocaleString("ja-JP", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  }) + " JST";
}
