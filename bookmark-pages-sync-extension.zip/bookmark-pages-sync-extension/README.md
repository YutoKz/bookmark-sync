# Public Bookmark Pages Sync

Chrome extension that syncs selected Chrome bookmark folders to a public GitHub Pages Markdown page.

## Features

- Manifest V3 Chrome extension
- Sync on Chrome startup
- Debounced sync after bookmark changes
- Multiple target bookmark folders
- Markdown output only
- GitHub Contents API update
- GitHub Pages-friendly `index.md`
- Strict domain allowlist filtering
- Always blocks Google Drive, Google Docs, Gmail, Slack, and Notion hosts
- Blocks non-HTTPS and URLs with sensitive query keys

## Setup

1. Create a public GitHub repository, for example `public-bookmarks`.
2. Enable GitHub Pages:
   - Settings → Pages
   - Source: Deploy from a branch
   - Branch: `main`
   - Folder: `/ root`
3. Create a fine-grained personal access token:
   - Repository access: only the target repository
   - Repository permissions: Contents: Read and write
4. Open Chrome Extensions:
   - `chrome://extensions`
   - Enable Developer mode
   - Load unpacked
   - Select this extension folder
5. Open the extension options page and configure:
   - GitHub owner
   - GitHub repo
   - Branch: `main`
   - Output path: `index.md`
   - Target bookmark folder names, one per line
   - Allowed domains, one per line
   - Token
6. Click Save, then Sync now.

## Safety model

This extension uses an allowlist. Only HTTPS URLs whose host matches an allowed domain are published. Non-HTTPS URLs, local URLs, and URLs with sensitive query keys are excluded.

GitHub Pages is public on the internet. Treat every published bookmark title and URL as public information.
