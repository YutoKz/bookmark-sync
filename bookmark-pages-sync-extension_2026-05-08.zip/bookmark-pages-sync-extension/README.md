# Public Bookmark Pages Sync

Chrome extension that syncs selected Chrome bookmark folders to a public GitHub Pages HTML page.

## Features

- Manifest V3 Chrome extension
- Sync on Chrome startup
- Debounced sync after bookmark changes
- Multiple target bookmark folders
- Polished single-file HTML output for GitHub Pages
- Nested bookmark folders rendered as nested lists
- Google Drive PDF/file preview embeds for public Drive share links
- GitHub Contents API update
- GitHub Pages-friendly `index.html`
- Strict domain allowlist filtering for normal links
- Blocks non-HTTPS and URLs with sensitive query keys

## Setup

1. Create a public GitHub repository, for example `public-bookmarks`.
2. Enable GitHub Pages:
   - Settings -> Pages
   - Source: Deploy from a branch
   - Branch: `main`
   - Folder: `/ root`
3. Create a fine-grained personal access token:
   - Repository access: only the target repository
   - Repository permissions: Contents: Read and write
4. Open Chrome Extensions:
   - `chrome://extensions`
   - Enable Developer mode
   - Load unpacked
   - Select this extension folder
5. Open the extension options page and configure:
   - GitHub owner
   - GitHub repo
   - Branch: `main`
   - Output path: `index.html`
   - Target bookmark folder names or nested paths, one per line
     - Example: `Public Bookmarks`
     - Example: `Research / Papers`
   - Domain filtering mode
     - Enable allowed-domain filtering to publish only listed domains
     - Disable it to publish any HTTPS domain that passes the safety checks
   - Allowed domains, one per line when filtering is enabled
   - Token
6. Click Save, then Sync now.

## Safety model

This extension can use an allowlist for normal links. When allowed-domain filtering is enabled, only HTTPS URLs whose host matches an allowed domain are published. When it is disabled, any HTTPS domain can be published as long as the URL passes the safety checks. Non-HTTPS URLs, local URLs, URLs with sensitive query keys, and always-blocked private-work hosts are excluded.

Google Drive `drive.google.com/file/d/...` and `drive.google.com/open?id=...` links are a special case: they can be published and embedded as previews so public PDFs and files can be shown on the page. The file must be shared publicly in Google Drive, otherwise the embedded preview will not load for visitors.

GitHub Pages is public on the internet. Treat every published bookmark title and URL as public information.

## Nested bookmark folders

When a target bookmark folder contains nested folders, the generated HTML preserves that structure as a nested bullet list. Folder names are shown as folder items, and bookmarks inside each folder are indented under that folder.

Example structure:

```md
Public Bookmarks
- Research
  - Example Paper
  - AI
    - Example Article
```